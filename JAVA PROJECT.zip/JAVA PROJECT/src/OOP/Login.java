package OOP;

import GUI.Buses;
import GUI.HomePage;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class Login implements ActionListener
{
    private JFrame frame;
    private JPanel P1,P2;
    private JLabel l1,l2,l3,l4,l5;
    private JTextField t1;
    private JButton b1,b2;
    private JPasswordField pa1;

    JCheckBox c1;
    private ImageIcon icon, logo;
    private JTextField emailField;
    private JPasswordField passwordField;

    private Cursor cursor;


    public Login()
    {

        // --------------Frame Layout Setup-----------
        frame = new JFrame("Login");
        frame.setSize(750, 510);
        frame.setLayout(null);


        cursor = new Cursor(Cursor.HAND_CURSOR);

/*
        //--------------creating two panel---------------

        P1 = new JPanel();
        P1.setBounds(0,0,350,500);
        P1.setLayout(null);


        P2 = new JPanel();
        P2.setBounds(350,0,350,500);
        P2.setBackground(new Color(240,240,240));
        P2.setLayout(null);




        //--------------- Label -----------------
        l1 = new JLabel("Don't have an account?");
        l1.setFont(new Font("Serif",Font.PLAIN,14));
        l1.setForeground(Color.black);
        l1.setBounds(530,13,150,15);
        P2.add(l1);

        l2 = new JLabel("ACCOUNT LOGIN IN HERE");
        l2.setFont(new Font("Serif",Font.PLAIN,24));
        l2.setForeground(Color.black);
        l2.setBounds(400,80,510,28);
        P2.add(l2);





        //------------------------ email NAME -------------

        l3 = new JLabel("Email");
        l3.setFont(new Font("Serif",Font.PLAIN,17));
        l3.setForeground(Color.black);
        l3.setBounds(400,140,200,20);
        P2.add(l3);

        t1 = new JTextField();
        t1.setFont(new Font("Serif",Font.PLAIN,19));
        t1.setBounds(400,170,270,27);
        P2.add(t1);



        //-------------------------password-----------------

        l4 = new JLabel("Password");
        l4.setFont(new Font("Serif",Font.PLAIN,18));
        l4.setForeground(Color.black);
        l4.setBounds(400,215,200,20);
        P2.add(l4);

        pa1 = new JPasswordField();
        pa1.setEchoChar('*');
        pa1.setFont(new Font("Serif",Font.PLAIN,19));
        pa1.setBounds(400,245,270,27);
        P2.add(pa1);



        //-------------------------------button----------------

        b1 = new JButton("Register");
        b1.setFont(new Font("Serif",Font.BOLD,14));
        b1.setForeground(Color.red);
        b1.setBackground(new Color(240,240,240));
        b1.setBorder(null);
        b1.setBounds(670,9,55,20);
        b1.addActionListener(this);
        b1.setFocusable(false);
        b1.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        P2.add(b1);


        b2 = new JButton("Login");
        b2.setFont(new Font("Serif",Font.BOLD,22));
        b2.setForeground(Color.white);
        b2.setBackground(new Color(102,140,208));
        b2.setBounds(400,340,270,38);
        b2.addActionListener(this);
        b2.setFocusable(false);
        b2.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        P2.add(b2);



        c1 = new JCheckBox("Show password");
        c1.setFont(new Font("Serif",Font.PLAIN,16));
        c1.setForeground(Color.black);
        c1.setBackground(new Color(240,240,240));
        c1.setBounds(398,280,270,38);
        c1.addActionListener(this);
        c1.setFocusable(false);
        c1.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        P2.add(c1);




        //image
        l5 = new JLabel(new ImageIcon(getClass().getResource("/image/Homee2.jpeg")));
        l5.setBounds(0,0,350,500);
        P1.add(l5);




        frame.add(P1);
        frame.add(P2);

        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null);

*/
        //=======================================================




        JLabel emailLabel = new JLabel("Email");
        emailLabel.setForeground(Color.red);
        emailLabel.setFont(new Font("Serif",Font.BOLD,18));
        emailLabel.setForeground(Color.black);
        emailLabel.setBounds(250, 83, 100, 30);
        frame.add(emailLabel);


        emailField = new JTextField();
        emailField.setBounds(350, 83, 200, 30);
        frame.add(emailField);


        // Password
        JLabel passwordLabel = new JLabel("Password");
        passwordLabel.setFont(new Font("Serif",Font.BOLD,18));
        passwordLabel.setForeground(Color.black);
        passwordLabel.setBounds(250, 133, 100, 30);
        frame.add(passwordLabel);

        passwordField = new JPasswordField();
        passwordField.setEchoChar('*');
        passwordField.setBounds(350, 133, 200, 30);
        frame.add(passwordField);



        // ==================Button================200, 250, 100, 30

        JButton loginButton = new JButton("Login");
        loginButton.setBounds(340, 185, 100, 30);
        loginButton.setCursor(cursor);
        loginButton.setBorder(null);
        loginButton.addActionListener(this);
        frame.add(loginButton);

        JButton registerButton = new JButton("Register");
        registerButton.setBounds(600, 185, 100, 30);
        registerButton.addActionListener(this);
        registerButton.setCursor(cursor);
        registerButton.setBorder(null);
        frame.add(registerButton);

        JButton back = new JButton("back");
        back.setBounds(50, 20, 100, 30);
        back.setCursor(cursor);
        back.setBorder(null);
        frame.add(back);
        back.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.setVisible(false);
                new HomePage();
            }
        });


        icon = new ImageIcon(getClass().getResource("/image/busgif11.gif"));
        l3 = new JLabel(icon);
        l3.setBounds(0,0,icon.getIconWidth(), icon.getIconHeight());
        frame.add(l3);


        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null);



    }



    public void actionPerformed(ActionEvent e)
    {
        if (e.getSource() instanceof JButton)
        {
            JButton button = (JButton) e.getSource();

            if (button.getText().equals("Login"))
            {
                login();
            }
            else if (button.getText().equals("Register"))
            {
                frame.dispose();
                new Registration();
            }
        }
        else if(c1.isSelected())
        {
            pa1.setEchoChar((char)0);
        }
        else
        {
            pa1.setEchoChar('*');
        }

    }


    private void login()
    {
        String email = emailField.getText();
        String password = new String(passwordField.getPassword());
        User user = null;

        if(email.isEmpty() || password.isEmpty())
        {
            JOptionPane.showMessageDialog(frame, "Please fill all fields!");
            return;
        }

        try {
            File file = new File("src\\data\\userdata.txt");

            if (!file.exists())
            {
                JOptionPane.showMessageDialog(frame, "No user registered yet!");
                return;
            }

            BufferedReader reader = new BufferedReader(new FileReader(file));

            String line;
            boolean loggedIn = false;

            while ((line = reader.readLine()) != null)
            {
                String[] parts = line.split(",");

                if (parts[1].equals(email) && parts[2].equals(password))
                {
                    loggedIn = true;
                    user = new User(parts[0], parts[1], parts[2], parts[3]);
                    break;
                }
            }
            reader.close();

            if (loggedIn)
            {
                JOptionPane.showMessageDialog(frame, "Login Successful!");

                frame.setVisible(false);
                Buses bus = new Buses();


            }
            else
            {
                JOptionPane.showMessageDialog(frame, "Invalid email or password!");
            }
        }
        catch (IOException ex) {
            ex.printStackTrace();
        }
    }



    public static void main(String[] args) {
        new Login();
    }








}

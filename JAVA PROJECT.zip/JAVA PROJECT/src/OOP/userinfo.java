package OOP;
import GUI.*;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class userinfo extends JFrame implements ActionListener
{
    private JLabel l1,l2,l3,l4,l5,l6,l7,l8,l9,l10,l11;

    private JButton b1,b2,b3;

    private JPanel P1,P2;

    //User user;

    //String line1,line2,line3,line4,line5;





    public userinfo()
    {
        super("user info");
        this.setSize(750,510);
        setLocationRelativeTo(null);

        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);





        // ----------------- Panel Set Up ------------------------

        P1 = new JPanel();
        P1.setBounds(0,0,750,80);
        P1.setBackground(new Color(124,124,124));
        P1.setBorder(BorderFactory.createLineBorder(Color.black));
        P1.setLayout(null);


        P2 = new JPanel();
        P2.setBounds(0,80,750,430);
        P2.setBackground(new Color(218,227,243));
        P2.setBorder(BorderFactory.createLineBorder(Color.black));
        P2.setLayout(null);


        ImageIcon icon = new ImageIcon(getClass().getResource("/image/logo.jpg"));
        this.setIconImage(icon.getImage());


        // ----------------- Panel 01 Set Up ------------------------

        l1 = new JLabel("User information");
        l1.setFont(new Font("Serif",Font.ITALIC | Font.BOLD,38));
        l1.setForeground(Color.black);
        l1.setBounds(20,22,480,35);
        P1.add(l1);


        b1 = new JButton("Sign out");
        b1.setFont(new Font("Serif",Font.BOLD,20));
        b1.setBackground(Color.green);
        b1.setBounds(600, 20, 110, 35);
        b1.addActionListener(this);
        b1.setFocusable(false);
        b1.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        P1.add(b1);



        // ----------------- Panel 02 Set Up ------------------------

        b2 = new JButton("Back");
        b2.setFont(new Font("Serif",Font.BOLD,20));
        b2.setBackground(Color.orange);
        b2.setBounds(40, 420, 100, 35);
        b2.addActionListener(this);
        b2.setFocusable(false);
        b2.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        P2.add(b2);


        b3 = new JButton("UPDATE PROFILE");
        b3.setFont(new Font("Serif",Font.BOLD,20));
        b3.setBackground(Color.pink);
        b3.setBounds(440, 420, 250, 35);
        b3.addActionListener(this);
        b3.setFocusable(false);
        b3.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        P2.add(b3);



        //name
        JLabel l22 = new JLabel("Name: ");
        l22.setFont(new Font("Serif",Font.ITALIC | Font.BOLD,20));
        l22.setBounds(28,120,200,35);
        this.add(l22);

        l2 = new JLabel();
        l2.setFont(new Font("Serif",Font.ITALIC | Font.BOLD,20));
        l2.setForeground(Color.black);
        l2.setBounds(100,120,480,35);
        P2.add(l2);


        //email
        JLabel l33 = new JLabel("email: ");
        l33.setFont(new Font("Serif",Font.ITALIC | Font.BOLD,20));
        l33.setBounds(28,170,200,35);
        this.add(l33);


        l3 = new JLabel();
        l3.setFont(new Font("Serif",Font.ITALIC | Font.BOLD,20));
        l3.setForeground(Color.black);
        l3.setBounds(100,170,480,35);
        P2.add(l3);


        //password
        JLabel l44 = new JLabel("Password: ");
        l44.setFont(new Font("Serif",Font.ITALIC | Font.BOLD,18));
        l44.setBounds(28,220,200,35);
        this.add(l44);

        l4 = new JLabel();
        l4.setFont(new Font("Serif",Font.ITALIC | Font.BOLD,20));
        l4.setForeground(Color.black);
        l4.setBounds(126,220,480,35);
        P2.add(l4);


        //gender
        JLabel l55 = new JLabel("gender: ");
        l55.setFont(new Font("Serif",Font.ITALIC | Font.BOLD,20));
        l55.setBounds(28,270,200,35);
        this.add(l55);

        l5 = new JLabel();
        l5.setFont(new Font("Serif",Font.ITALIC | Font.BOLD,20));
        l5.setForeground(Color.black);
        l5.setBounds(100,270,480,35);
        P2.add(l5);







        try
        {
            File file = new File("src\\data\\userdata.txt");

            if (!file.exists())
            {
                JOptionPane.showMessageDialog(this, "No user registered yet!");
                return;
            }

            BufferedReader readers = new BufferedReader(new FileReader(file));

            String line;

            while ((line = readers.readLine()) != null)
            {
                String[] parts = line.split(",");
                l2.setText(parts[0]);
                l3.setText(parts[1]);
                l4.setText(parts[2]);
                l5.setText(parts[3]);


            }
            readers.close();


        }

        catch(IOException e)
        { }




        this.add(P1);
        this.add(P2);

        setVisible(true);

    }



    public void actionPerformed(ActionEvent ae){


        if(ae.getSource()==b1)
        {
            this.setVisible(false);
            new Login();
        }

        else if(ae.getSource()==b2)
        {
            Buses m = new Buses();
            this.setVisible(false);
            m.setVisible(true);
        }

        else if(ae.getSource()==b3)
        {
            this.setVisible(false);
            passwordChange p = new passwordChange();
            p.setVisible(true);
        }


    }



    public static void main(String [] args)
    {
        userinfo l = new userinfo();

    }



}

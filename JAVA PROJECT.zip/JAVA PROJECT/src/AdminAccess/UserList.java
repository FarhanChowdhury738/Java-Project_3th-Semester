package AdminAccess;


import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;

public class UserList implements ActionListener {
    private JFrame frame;
    private JLabel l1,l2;
    private JTable table;
    private JButton removeButton,backButton;

    public UserList()
    {
        frame = new JFrame("User List");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        String[][] userData = readUserDataFrom("src\\data\\userdata.txt");
        String[] collumNames = {"Name","E-mail","Password","Gender"};
        DefaultTableModel tableModel = new DefaultTableModel(userData,collumNames);

        table = new JTable(tableModel);

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(137, 121, 491, 242);

        frame.add(scrollPane);

        removeButton = new JButton("Remove User");
        removeButton.setBorder(null);
        removeButton.setBounds(200, 400, 180, 30);
        removeButton.addActionListener(this);
        frame.add(removeButton);

        backButton = new JButton("Back");
        backButton.setBorder(null);
        backButton.setBounds(550, 400, 100, 30);
        backButton.addActionListener(this);
        frame.add(backButton);

        l2 = new JLabel("User List");
        Font font = new Font("Times New Roman", Font.PLAIN, 48);
        l2.setFont(font);
        l2.setForeground(Color.decode("#0f0aa7"));
        l2.setBounds(282,14,185,57);
        frame.add(l2);

        ImageIcon BG = new ImageIcon("image/BG.png");
        l1 = new JLabel(BG);
        l1.setBounds(0,0,750,510);
        frame.add(l1);





        frame.setSize(750,510);
        frame.setLocationRelativeTo(null);
        frame.setLayout(null);
        frame.setVisible(true);
    }

    private static String[][] readUserDataFrom(String filename)
    {
        try(BufferedReader br = new BufferedReader(new FileReader(filename)))
        {
            long lineCount = br.lines().count();
            br.close();
            BufferedReader reader = new BufferedReader(new FileReader(filename));
            String[][] userData = new String[(int)lineCount][4];
            String line;
            int row = 0;
            while((line = reader.readLine())!=null)
            {
                String[] fields = line.split(",");
                userData[row++] = fields;
            }
            return userData;
        }
        catch(IOException e)
        {
            e.printStackTrace();
            return new String[0][0];
        }
    }
    private void updateSourceFile(String[][] data)
    {
        try (PrintWriter out = new PrintWriter(new FileWriter("userdata.txt")))
        {
            for (String[] row : data)
            {
                out.println(String.join(",", row));
            }
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
    }


    public void actionPerformed(ActionEvent e){
        if(e.getSource() == removeButton){
            int selectedRow = table.getSelectedRow();
            if (selectedRow != -1) {
                DefaultTableModel model = (DefaultTableModel) table.getModel();
                model.removeRow(selectedRow);
                String[][] newData = new String[model.getRowCount()][4];
                for (int i = 0; i < model.getRowCount(); i++) {
                    for (int j = 0; j < model.getColumnCount(); j++) {
                        newData[i][j] = model.getValueAt(i, j).toString();
                    }
                }
                updateSourceFile(newData);
            } else {
                JOptionPane.showMessageDialog(frame, "Please select a row to remove.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
        if(e.getSource() == backButton){
            frame.setVisible(false);
            new Adminpanel();
        }
    }


    public static void main(String[] args) {
        new UserList();
    }

}

package AdminAccess;
import OOP.*;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Adminpanel implements ActionListener {
    private JFrame frame;
    private JButton b1,b2,b3;
    private JLabel l1,l2;

    public Adminpanel()
    {
        frame = new JFrame("Admin Panel");


        l2 = new JLabel("Admin Panel");
        l2.setBounds(245,88,263,57);
        Font font1 = new Font("Times New Roman", Font.PLAIN, 48);
        l2.setFont(font1);
        l2.setForeground(Color.red);
        frame.add(l2);


        b1 = new JButton("User List");
        b1.setBorder(null);
        b1.setBounds(190,208,139,49);
        Font font = new Font("Times New Roman", Font.PLAIN, 18);
        b1.setFont(font);
        b1.setForeground(Color.black);
        b1.addActionListener(this);
        frame.add(b1);

        b2 = new JButton("Add User");
        b2.setBorder(null);
        b2.setBounds(407,208,139,49);
        b2.setFont(font);
        b2.setForeground(Color.black);
        b2.addActionListener(this);
        frame.add(b2);

        b3 = new JButton("Log out");
        b3.setBorder(null);
        b3.setBounds(319,302,112,40);
        b3.setFont(font);
        b3.setForeground(Color.black);
        b3.addActionListener(this);
        frame.add(b3);


        ImageIcon Bground = new ImageIcon("image/admin.png");
        l1 = new JLabel(Bground);
        l1.setBounds(0,0,750,510);
        frame.add(l1);




        frame.setSize(750,510);
        frame.setLayout(null);
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null);
    }


    public void actionPerformed(ActionEvent e)
    {
        if(e.getSource() == b2){
            frame.setVisible(false);
            new AdminRegistration();
        }
        if(e.getSource() == b1){
            frame.setVisible(false);
            new UserList();
        }
        if(e.getSource() == b3){
            frame.setVisible(false);
            new AdminLogin();
        }

    }

    public static void main(String[] args) {
        new Adminpanel();
    }

}
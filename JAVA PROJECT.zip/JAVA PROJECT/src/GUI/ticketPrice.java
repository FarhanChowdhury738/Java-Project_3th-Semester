package GUI;
import OOP.userinfo;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ticketPrice extends JFrame implements ActionListener
{
    private JLabel l1,l2,l3,l4,l5,l6,l7,l8,l9,l10,l11,l12,l13,l14,l15,l16,l17,l18,l19,l20,l21,l22,l23,l24,l25;

    private JButton b1,b2,b3,b4,b5,b6;

    private JPanel P1,P2,P3,P4,P5;

    private Cursor cursor;







    public ticketPrice()
    {
        super("Ticket price");
        this.setSize(750,510);
        setLocationRelativeTo(null);

        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        cursor = new Cursor(Cursor.HAND_CURSOR);

// ----------------- Panel Set Up ------------------------

        P1 = new JPanel();
        P1.setBounds(0,0,750,50);
        P1.setBackground(new Color(118,113,113));
        P1.setBorder(BorderFactory.createLineBorder(Color.black));
        P1.setLayout(null);

        P2 = new JPanel();
        P2.setBounds(0,40,750,50);
        P2.setBackground(new Color(219,219,219));
        P2.setBorder(BorderFactory.createLineBorder(Color.black));
        P2.setLayout(null);


        P3 = new JPanel();
        P3.setBounds(0,100,750,400);
        P3.setBackground(new Color(216,228,250));
        P3.setLayout(null);


        /*
        P3 = new JPanel();
        P3.setBounds(0,90,245,410);
        P3.setBackground(new Color(244,204,204));
        P3.setBorder(BorderFactory.createLineBorder(Color.black));
        P3.setLayout(null);
        */

        P4 = new JPanel();
        P4.setBounds(245,90,245,410);
        P4.setBackground(new Color(192,246,209));
        P4.setBorder(BorderFactory.createLineBorder(Color.black));
        P4.setLayout(null);

        /*
        P5 = new JPanel();
        P5.setBounds(490,90,260,410);
        //P5.setBackground(new Color(157,195,230));
        P5.setBorder(BorderFactory.createLineBorder(Color.black));
        P5.setLayout(null);
           */

        ImageIcon icon = new ImageIcon(getClass().getResource("/image/logo.jpg"));
        this.setIconImage(icon.getImage());


// ----------------- Panel 01 Set Up ------------------------

        l1 = new JLabel("Bus Ticket");
        l1.setFont(new Font("Serif",Font.ITALIC | Font.BOLD,36));
        l1.setForeground(Color.ORANGE);
        l1.setBounds(20,8,180,35);
        P1.add(l1);

        l2 = new JLabel(". . . Enjoy your journey!");
        l2.setFont(new Font("Serif",Font.ITALIC | Font.BOLD,12));
        l2.setForeground(Color.orange);
        l2.setBounds(190,27,150,15);
        P1.add(l2);


        b1 = new JButton(new ImageIcon(getClass().getResource("/image/logo.png")));
        b1.setBorder(null);
        b1.setBounds(685,9,34,32);
        b1.addActionListener(this);
        b1.setFocusable(false);
        b1.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        P1.add(b1);



        // ----------------- Panel 02 Set Up ------------------------

        b2 = new JButton("Buses");
        b2.setFont(new Font("Serif",Font.PLAIN,18));
        b2.setForeground(Color.black);
        b2.setBackground(new Color(219,219,219));
        b2.setBorder(null);
        b2.setBounds(65,22,60,15);
        b2.addActionListener(this);

        b2.setCursor(cursor);
        P2.add(b2);



        b3 = new JButton("Bus Time");
        b3.setFont(new Font("Serif",Font.PLAIN,18));
        b3.setForeground(Color.black);
        b3.setBackground(new Color(219,219,219));
        b3.setBorder(null);
        b3.setBounds(230,22,75,15);
        b3.addActionListener(this);

        b3.setCursor(cursor);
        P2.add(b3);



        b4 = new JButton("Ticket Price");
        b4.setFont(new Font("Serif",Font.BOLD,18));
        b4.setForeground(Color.red);
        b4.setBackground(new Color(209,209,209));
        b4.setBorder(null);
        b4.setBounds(405,10,140,38);
        b4.addActionListener(this);

        b4.setCursor(cursor);
        P2.add(b4);



        b5 = new JButton("About Us");
        b5.setFont(new Font("Serif",Font.PLAIN,18));
        b5.setForeground(Color.black);
        b5.setBackground(new Color(219,219,219));
        b5.setBorder(null);
        b5.setBounds(600,22,80,15);
        b5.addActionListener(this);
        b5.setFocusable(false);
        b5.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        P2.add(b5);



        // ----------------- Panel 03 Set Up imagess ------------------------


        l2 = new JLabel(new ImageIcon(getClass().getResource("/image/bus1.png")));
        l2.setBounds(20,100,130,170);
        P3.add(l2);

        l3 = new JLabel(new ImageIcon(getClass().getResource("/image/bus2.png")));
        l3.setBounds(20,290,130,170);
        P3.add(l3);

        l4 = new JLabel(new ImageIcon(getClass().getResource("/image/bus3.png")));
        l4.setBounds(385,100,130,170);
        P3.add(l4);

        l5 = new JLabel(new ImageIcon(getClass().getResource("/image/bus4.png")));
        l5.setBounds(385,295,130,170);
        P3.add(l5);



        // ----------------- Panel 03 Set Up image names ------------------------

        l6 = new JLabel("AB Travels");
        l6.setFont(new Font("Serif",Font.ITALIC|Font.BOLD,17));
        l6.setForeground(Color.black);
        l6.setBackground(Color.GREEN);
        l6.setBounds(170,110,250,20);
        P3.add(l6);

        l7 = new JLabel("BC Travels");
        l7.setFont(new Font("Serif",Font.ITALIC|Font.BOLD,17));
        l7.setForeground(Color.black);
        l7.setBounds(170,300,250,20);
        P3.add(l7);

        l8 = new JLabel("CD Travels");
        l8.setFont(new Font("Serif",Font.ITALIC|Font.BOLD,17));
        l8.setForeground(Color.black);
        l8.setBounds(540,110,250,20);
        P3.add(l8);

        l9 = new JLabel("DE Travels");
        l9.setFont(new Font("Serif",Font.ITALIC|Font.BOLD,17));
        l9.setForeground(Color.black);
        l9.setBounds(540,300,250,20);
        P3.add(l9);






        //  time for Bus 01

        l10 = new JLabel("<html> NON AC Bus <br/> 300tk <br/> </html>");
        l10.setFont(new Font("Serif",Font.BOLD,19));
        l10.setForeground(Color.black);


        l10.setBounds(180,160,150,43);
        P3.add(l10);


        // time for Bus 02

        l14 = new JLabel("<html> NON AC Bus <br/> 500tk <br/> </html>");
        l14.setFont(new Font("Serif",Font.BOLD,19));
        l14.setForeground(Color.black);

        l14.setBounds(180,350,150,43);
        P3.add(l14);



        // time for Bus 03

        l18 = new JLabel("<html> AC Bus <br/> 800tk <br/> </html>");
        l18.setFont(new Font("Serif",Font.BOLD,19));
        l18.setForeground(Color.black);

        l18.setBounds(540,160,100,43);
        P3.add(l18);



        // time for Bus 04

        l18 = new JLabel("<html> AC Bus <br/> 900tk <br/> </html>");
        l18.setFont(new Font("Serif",Font.BOLD,19));
        l18.setForeground(Color.black);

        l18.setBounds(540,350,100,43);
        P3.add(l18);





       /*
// ----------------- Panel 03,04,05 Set Up images ------------------------

       l2 = new JLabel(new ImageIcon(getClass().getResource("/image/regular seat.jpg")));
	   l2.setBounds(16,25,210,140);
	   P3.add(l2);


       l3 = new JLabel(new ImageIcon(getClass().getResource("/image/premium seat.jpg")));
	   l3.setBounds(16,25,210,140);
	   P4.add(l3);


       l4 = new JLabel(new ImageIcon(getClass().getResource("/image/vip seat.jpg")));
	   l4.setBounds(507,115,210,140);
	   P5.add(l4);


       l5 = new JLabel("Regular seat");
       l5.setFont(new Font("Serif",Font.PLAIN,22));
	   l5.setBounds(60,120,210,140);
	   P3.add(l5);


       l6 = new JLabel("Premium seat");
       l6.setFont(new Font("Serif",Font.PLAIN,22));
	   l6.setBounds(60,120,210,140);
	   P4.add(l6);


       l7 = new JLabel("VIP seat");
       l7.setFont(new Font("Serif",Font.PLAIN,21));
	   l7.setBounds(575,208,210,140);
	   P5.add(l7);


       l8 = new JLabel("Price : 300 Tk / each");
       l8.setFont(new Font("Serif",Font.BOLD,22));
	   l8.setBounds(30,220,210,140);
	   P3.add(l8);


       l9 = new JLabel("Price : 500 Tk / each");
       l9.setFont(new Font("Serif",Font.BOLD,22));
	   l9.setBounds(30,220,210,140);
	   P4.add(l9);


       l10 = new JLabel("Price : 700 Tk / each");
       l10.setFont(new Font("Serif",Font.BOLD,21));
	   l10.setBounds(520,312,210,140);
	   P5.add(l10);
*/

        this.add(P1);
        this.add(P2);
        this.add(P3);
        //  this.add(P4);
        //this.add(P5);
        setVisible(true);

    }



    public void actionPerformed(ActionEvent ae){

        if(ae.getSource()==b1)
        {
            this.setVisible(false);
            userinfo u = new userinfo();
            u.setVisible(true);
        }

        else if(ae.getSource()==b2)
        {
            this.setVisible(false);
            Buses s = new Buses();
            s.setVisible(true);
        }

        else if(ae.getSource()==b3)
        {
            this.setVisible(false);
            BusTime t = new BusTime();
            t.setVisible(true);
        }

        else if(ae.getSource()==b5)
        {
            this.setVisible(false);
            location l = new location();
            l.setVisible(true);
        }


    }


    public static void main(String [] args)
    {
        ticketPrice t = new ticketPrice();

    }







}

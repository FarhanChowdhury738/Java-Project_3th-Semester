package GUI;
import OOP.*;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class BusTime  extends JFrame implements ActionListener
{

    private JLabel l1,l2,l3,l4,l5,l6,l7,l8,l9,l10,l11,l12,l13,l14,l15,l16,l17,l18,l19,l20,l21,l22,l23,l24,l25;

    private JButton b1,b2,b3,b4,b5;

    private JPanel P1,P2,P3;

    private Cursor cursor;








    public BusTime()
    {
        super("Bus Time");
        this.setSize(750,520);
        setLocationRelativeTo(null);

        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);


        cursor = new Cursor(Cursor.HAND_CURSOR);

        // ----------------- Panel Set Up ------------------------

        P1 = new JPanel();
        P1.setBounds(0,0,750,50);
        P1.setBackground(new Color(118,113,113));
        P1.setBorder(BorderFactory.createLineBorder(Color.black));
        P1.setLayout(null);

        P2 = new JPanel();
        P2.setBounds(0,40,750,50);
        P2.setBackground(new Color(219,219,219));
        P2.setBorder(BorderFactory.createLineBorder(Color.black));
        P2.setLayout(null);

        P3 = new JPanel();
        P3.setBounds(0,100,750,400);
        P3.setBackground(new Color(216,228,250));
        P3.setLayout(null);

        ImageIcon icon = new ImageIcon(getClass().getResource("/image/logo.jpg"));
        this.setIconImage(icon.getImage());


// ----------------- Panel 01 Set Up ------------------------

        l1 = new JLabel("Bus Ticket");
        l1.setFont(new Font("Serif",Font.ITALIC | Font.BOLD,36));
        l1.setForeground(Color.ORANGE);
        l1.setBounds(20,8,180,35);
        P1.add(l1);

        l2 = new JLabel(". . . Enjoy your journey!");
        l2.setFont(new Font("Serif",Font.ITALIC | Font.BOLD,12));
        l2.setForeground(Color.orange);
        l2.setBounds(190,27,150,15);
        P1.add(l2);


        b1 = new JButton(new ImageIcon(getClass().getResource("/image/logo.png")));
        b1.setBounds(685,9,36,36);

        b1.setBorder(null);
        b1.addActionListener(this);

        b1.setCursor(cursor);
        P1.add(b1);




        // ----------------- Panel 02 Set Up ------------------------

        b2 = new JButton("Buses");
        b2.setFont(new Font("Serif",Font.PLAIN,18));
        b2.setForeground(Color.black);
        b2.setBackground(new Color(219,219,219));
        b2.setBorder(null);
        b2.setBounds(65,18,60,25);
        b2.addActionListener(this);

        b2.setCursor(cursor);
        P2.add(b2);



        b3 = new JButton("Bus Time");
        b3.setFont(new Font("Serif",Font.BOLD,18));
        b3.setForeground(Color.red);
        b3.setBackground(new Color(209,209,209));
        b3.setBorder(null);
        b3.setBounds(220,10,150,38);
        b3.addActionListener(this);

        b3.setCursor(cursor);
        P2.add(b3);



        b4 = new JButton("Ticket Price");
        b4.setFont(new Font("Serif",Font.PLAIN,18));
        b4.setForeground(Color.black);
        b4.setBackground(new Color(219,219,219));
        b4.setBorder(null);
        b4.setBounds(405,22,100,15);
        b4.addActionListener(this);

        b4.setCursor(cursor);
        P2.add(b4);



        b5 = new JButton("About Us");
        b5.setFont(new Font("Serif",Font.PLAIN,18));
        b5.setForeground(Color.black);
        b5.setBackground(new Color(219,219,219));
        b5.setBorder(null);
        b5.setBounds(600,22,80,15);
        b5.addActionListener(this);

        b5.setCursor(cursor);
        P2.add(b5);






// ----------------- Panel 03 Set Up imagess ------------------------


        l2 = new JLabel(new ImageIcon(getClass().getResource("/image/bus1.png")));
        l2.setBounds(20,100,130,170);
        P3.add(l2);

        l3 = new JLabel(new ImageIcon(getClass().getResource("/image/bus2.png")));
        l3.setBounds(20,295,130,170);
        P3.add(l3);

        l4 = new JLabel(new ImageIcon(getClass().getResource("/image/bus3.png")));
        l4.setBounds(385,100,130,170);
        P3.add(l4);

        l5 = new JLabel(new ImageIcon(getClass().getResource("/image/bus4.png")));
        l5.setBounds(385,295,130,170);
        P3.add(l5);






// ----------------- Panel 03 Set Up image names ------------------------

        l6 = new JLabel("AB Travels");
        l6.setFont(new Font("Serif",Font.ITALIC|Font.BOLD,17));
        l6.setForeground(Color.black);
        l6.setBackground(Color.GREEN);
        l6.setBounds(170,110,250,20);
        P3.add(l6);

        l7 = new JLabel("BC Travels");
        l7.setFont(new Font("Serif",Font.ITALIC|Font.BOLD,17));
        l7.setForeground(Color.black);
        l7.setBounds(170,300,250,20);
        P3.add(l7);

        l8 = new JLabel("CD Travels");
        l8.setFont(new Font("Serif",Font.ITALIC|Font.BOLD,17));
        l8.setForeground(Color.black);
        l8.setBounds(540,110,250,20);
        P3.add(l8);

        l9 = new JLabel("DE Travels");
        l9.setFont(new Font("Serif",Font.ITALIC|Font.BOLD,17));
        l9.setForeground(Color.black);
        l9.setBounds(540,300,250,20);
        P3.add(l9);






        //  time for Bus 01

        l10 = new JLabel("   6.00 AM");
        l10.setFont(new Font("Serif",Font.BOLD,15));
        l10.setForeground(Color.black);
        l10.setOpaque(true);
        l10.setBackground(new Color(152,236,156));
        l10.setBounds(180,160,90,28);
        P3.add(l10);


        // time for Bus 02

        l14 = new JLabel("   8.00 AM");
        l14.setFont(new Font("Serif",Font.BOLD,15));
        l14.setForeground(Color.black);
        l14.setOpaque(true);
        l14.setBackground(new Color(152,236,156));
        l14.setBounds(180,350,90,28);
        P3.add(l14);



        // time for Bus 03

        l18 = new JLabel("   8.00 PM");
        l18.setFont(new Font("Serif",Font.BOLD,15));
        l18.setForeground(Color.black);
        l18.setOpaque(true);
        l18.setBackground(new Color(152,236,156));
        l18.setBounds(540,160,90,28);
        P3.add(l18);



        // time for Bus 04

        l18 = new JLabel("   10.00 PM");
        l18.setFont(new Font("Serif",Font.BOLD,15));
        l18.setForeground(Color.black);
        l18.setOpaque(true);
        l18.setBackground(new Color(152,236,156));
        l18.setBounds(540,350,90,28);
        P3.add(l18);



        this.add(P1);
        this.add(P2);
        this.add(P3);
        setVisible(true);

    }


    public void actionPerformed(ActionEvent ae){

        //user information
        if(ae.getSource()==b1)
        {
            this.setVisible(false);
            userinfo u = new userinfo();
            u.setVisible(true);
        }

        // Bus page
        else if(ae.getSource()==b2)
        {
            this.setVisible(false);
            Buses s = new Buses();
            s.setVisible(true);
        }

        //Ticket pricing page
        else if(ae.getSource()==b4)
        {
            this.setVisible(false);
            ticketPrice t = new ticketPrice();
            t.setVisible(true);
        }

        //Location page
        else if(ae.getSource()==b5)
        {
            this.setVisible(false);
            location l = new location();
            l.setVisible(true);
        }

    }




    public static void main(String [] args)
    {
        BusTime s = new BusTime();

    }


}

package GUI;
import OOP.*;
import AdminAccess.*;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class HomePage extends JFrame implements ActionListener
{
    private JLabel l1;

    private JButton b1,b2,adminlogin;

    private JPanel P1;

    private ImageIcon i1;



    public HomePage ()
    {
        super(" homepage ");
        this.setSize(750,500);
        setLocationRelativeTo(null);
        setResizable(false);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);



        // panel
        P1 = new JPanel();
        P1.setBounds(0,0,750,500);
        P1.setLayout(null);



        ImageIcon icon = new ImageIcon(getClass().getResource("/image/logo.jpg"));
        this.setIconImage(icon.getImage());




        //button
        b1 = new JButton("Exit");
        b1.setFont(new Font("Serif",Font.BOLD,23));
        b1.setForeground(Color.white);
        b1.setBackground( Color.red);
        b1.setBorder(null);
        b1.setBounds(25,400,88,36);
        b1.addActionListener(this);
        b1.setFocusable(false);
        b1.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        P1.add(b1);



        adminlogin = new JButton("Admin Login");
        adminlogin.setFont(new Font("Serif",Font.BOLD,23));
        adminlogin.setForeground(Color.white);
        adminlogin.setBackground(new Color(102,140,208));
        adminlogin.setBounds(500,20,180,40);
        adminlogin.addActionListener(this);
        adminlogin.setFocusable(false);
        adminlogin.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        P1.add(adminlogin);





        b2 =  new JButton ("Get started");
        b2.setFont(new Font("Serif",Font.BOLD,23));
        b2.setForeground(Color.white);
        b2.setBackground(new Color(102,140,208));
        b2.setBounds(450,390,220,40);
        b2.addActionListener(this);
        b2.setFocusable(false);
        b2.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        P1.add(b2);



        //image
        l1 = new JLabel(new ImageIcon(getClass().getResource("/image/Busgif11.gif")));
        l1.setBounds(0,0,750,500);
        P1.add(l1);


        this.add(P1);
        setVisible(true);


    }


    public void actionPerformed(ActionEvent ae){

        if(ae.getSource()==b1)
        {
            this.dispose();
        }

        //get  Start
        else if(ae.getSource()==b2)
        {
            this.add(P1);
            this.setVisible(false);
            new Login();
        }

        //admin login
        else if(ae.getSource()==adminlogin)
        {
            this.dispose();
            new AdminLogin();
        }
    }

    public static void main(String[] args)
    {
        new HomePage();
    }

}
